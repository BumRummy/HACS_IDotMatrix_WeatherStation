# iDotMatrix Weather Matrix — beta

A Home Assistant custom integration for 32x32 and 64x64 iDotMatrix BLE displays.

## Included default pack

The integration now ships with the animated **Giraffe Weather** 64x64 pack. If you leave Animation Pack Folder at its default value, no separate GIF files are required.

Included scenes: rainy, sunny, thunderstorm, snowy, windy, clear night, foggy, extreme heat, and freezing.

## Pixel-matrix font

v0.3 replaces the generic PIL font with built-in bitmap fonts designed specifically
for the 64x64 LED matrix. The clock and temperature use a chunky 5x7 font, while
the weather label uses a compact 3x5 alphabet so long labels such as FREEZING and
THUNDER still fit the lower-right region. No external TTF/font file is required.

## What it does

- Selects a GIF based on a Home Assistant `weather.*` entity.
- Keeps the source GIF frames cached in memory.
- Replaces only the configured information rectangles with a solid color (black by default).
- Draws live clock, temperature, and weather condition text into those rectangles.
- Uploads the resulting GIF to the iDotMatrix over Bluetooth.
- Re-renders only when a visible value changes.

## Important technical note

This v0.1 beta uses the reliable iDotMatrix GIF upload protocol. The panel's public/reverse-engineered protocol does not currently prove that arbitrary text/pixel overlays can coexist with a running native GIF. Therefore v0.1 re-encodes and uploads the cached animation when the minute, temperature, or condition changes. It does **not** regenerate the artwork or call any AI/image generator.

A future transport backend can replace the upload step with true native overlays if the 64x64 firmware exposes them.

## Install

1. Extract `custom_components/idm_weather_matrix` into:
   `/config/custom_components/idm_weather_matrix`
2. Restart Home Assistant.
3. Create a pack folder, for example:
   `/config/idm_weather_matrix/giraffe`
4. Put 64x64 GIFs in it:
   - `sunny.gif`
   - `partly_cloudy.gif`
   - `cloudy.gif`
   - `rain.gif`
   - `thunderstorm.gif`
   - `snow.gif`
   - `windy.gif`
   - `fog.gif`
   - `clear_night.gif`
   - `default.gif`
5. Optionally copy/edit `sample_pack/manifest.json`.
6. In Home Assistant: Settings → Devices & services → Add Integration → **iDotMatrix Weather Matrix**.
7. Enter the panel Bluetooth address, choose your `weather.*` entity, and point Pack Path at your pack folder.

## 64x64 default layout

- Clock: x=11, y=0, w=42, h=11
- Temperature: x=0, y=53, w=26, h=11
- Condition: x=27, y=53, w=37, h=11

The rectangles are simply painted over the GIF pixels; no separate mask image is needed.

## Pack manifest

See `sample_pack/manifest.json`. Background/foreground colors and region positions can be changed there.

## Beta caveats

- Bluetooth writes vary across IDM firmware revisions; 64x64 hardware testing is still required.
- Some Home Assistant hosts use Bluetooth proxies. Large GIF upload behavior over proxies may differ from local Bluetooth.
- The default PIL bitmap font is deliberately tiny and dependency-free. A pixel font option can be added after device testing.
